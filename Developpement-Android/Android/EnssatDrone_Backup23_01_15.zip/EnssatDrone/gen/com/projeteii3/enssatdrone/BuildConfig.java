/** Automatically generated file. DO NOT MODIFY */
package com.projeteii3.enssatdrone;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}